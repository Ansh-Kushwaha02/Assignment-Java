import in.mindcraft.Student;
import in.mindcraft.pack2.Batch;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		s1.displayInfo();
		
		Batch b1=new Batch();
		b1.displayInfo();

	}

}
