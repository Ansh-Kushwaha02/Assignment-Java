package in.mindcraft.pack2;

public class Batch {
	private String coursename="Maths";
	private int batchstrentgh=25;
	
	public void displayInfo() 
	{
		  System.out.println("CourseName:"+coursename+" Batchstrentgh:"+batchstrentgh);
	      }	

}
