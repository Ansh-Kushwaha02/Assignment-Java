package in.mindcraft;

public class Student {

	private String name="Ansh";
	private int roll_No=24;
	
	public void displayInfo() 
	{
		  System.out.println("Name:"+name+" RollNo:"+roll_No);
	   }
}
