package in.mindcraft;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Test {


		public static void main(String[] args) {
			// TODO Auto-generated method stub

//			Set<Integer> set=new HashSet<>();
//			set.add(10);
//			set.add(15);
//			set.add(2);
//			set.add(4);
//			set.add(1);
//			set.add(0);
//			set.add(56);
//			set.add(34);
//			set.add(10);
//			set.add(10);
//			set.add(null);
	//
//			set.add(null);
	//System.out.println(set);
//			
			
//			//linkedHashSet
//					Set<Integer> set=new LinkedHashSet<>();
//					set.add(10);
//					set.add(15);
//					set.add(2);
//					set.add(4);
//					set.add(1);
//					set.add(1);
	//
//					set.add(0);
//					set.add(56);
//					set.add(34);
//					set.add(10);
//					set.add(null);
	//
//					System.out.println(set);
			//TreeSet
					Set<Integer> set=new TreeSet<>();
					set.add(10);
					set.add(15);
					set.add(2);
					set.add(4);
					set.add(1);
					set.add(0);
					set.add(56);
					set.add(34);
					set.add(10);
					System.out.println(set);

	}

}
