
class Account
{
	private double balance;
	private double deposit;
	private double withdraw;
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
