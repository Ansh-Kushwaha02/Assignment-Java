import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> set = new TreeSet<>();
		set.add("Apple");
		set.add("Banana");
		set.add("Mango");
		set.add("coconut");
		
		 System.out.println(set);
		 System.out.println(set.contains("Mango"));
		 

	}

}
